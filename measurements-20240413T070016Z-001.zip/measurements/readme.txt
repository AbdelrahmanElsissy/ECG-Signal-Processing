naming scheme: artifact-condition.bdf

artifact means
- normal = without distortion
- baseline = baseline wandering distortion

condition means
- normal = without condition
etc.
	